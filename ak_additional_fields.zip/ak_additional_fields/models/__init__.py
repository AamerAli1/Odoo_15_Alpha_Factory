
from . import alt_name
from . import product_fields
from . import qcfield
from . import invoice_fields
from . import res_partner

